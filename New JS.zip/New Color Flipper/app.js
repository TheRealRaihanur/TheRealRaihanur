colors = ['red', 'blue','green', 'yellow', 'white', 'orange', 'purple'];

const btn = document.querySelector('.btn');
let span = document.querySelector('.background-color');

btn.addEventListener('click', function(){
    let random = Math.floor(Math.random()*colors.length);
    console.log(random);
    document.body.style.background = colors[random];
    span.textContent = `${colors[random]}`;


})