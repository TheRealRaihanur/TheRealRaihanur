// dynamically setting date
const date = document.getElementById('date');
date.innerHTML = new Date().getFullYear();

// scroll-functions
// fix nav bar

const nav = document.getElementById('nav');
const home = document.getElementById('home');
const topLink = document.querySelector('.top-link');

window.addEventListener('scroll',function(){
    let scrollHeight =pageYOffset;
    const navHeight = nav.getBoundingClientRect().height;
    const homeHeight = home.getBoundingClientRect().height;
    
    
    
    if(scrollHeight >= navHeight ){
        nav.classList.add('fixed-nav');
    }
    else{
        nav.classList.remove('fixed-nav');
    }

    if(scrollHeight >= homeHeight ){
        topLink.classList.add('show-top-link');
    }
    else{
        topLink.classList.remove('show-top-link');
    }
});

//proper scroll

const scrollLinks =  document.querySelectorAll('.scroll-link');

scrollLinks.forEach(function(link){
    link.addEventListener('click', function(e){
        e.preventDefault();
        const id = e.currentTarget.getAttribute('href').slice(1);
        const element = document.getElementById(id);
        //calculating heights
        const navHeight = nav.getBoundingClientRect().height;
        const linksContainerHeight = linksContainer.getBoundingClientRect().height;  
        let fixedNav = nav.classList.contains('fixed-nav');
        let position = element.offsetTop - navHeight;
        if(navHeight > 58){
            position = position + linksContainerHeight;
        }
        window.scrollTo(0,position);
        linksContainer.style.height = 0;
        
        
    
    });
});

//nav-toggle 
const toggle = document.querySelector('.nav-toggle');
const linksContainer = document.querySelector('.links-container');
const links = document.querySelector('.links');

toggle.addEventListener('click', function(){
const linksContainerHeight =  linksContainer.getBoundingClientRect().height;
console.log(linksContainerHeight);
const linksHeight =  links.getBoundingClientRect().height;


if(linksContainerHeight === 0){
    linksContainer.style.height = `${linksHeight}px`;
}
else{
    linksContainer.style.height = 0;
}
});
