const preloader =  document.querySelector('.preloader');
const btn =  document.querySelector('.switch-container');
const video =  document.querySelector('.video-container');



window.addEventListener('load', function(){
    preloader.classList.add('hide-preloader');
});

btn.addEventListener('click', function(){
if(btn.classList.contains('slide')){
    btn.classList.remove('slide');
    video.play();
}
else{
    btn.classList.add('slide');
    video.pause();
}
});