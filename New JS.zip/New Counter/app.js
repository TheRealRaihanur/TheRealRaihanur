const count = document.getElementById('count');
const decrease = document.querySelector('.decrease');
const increase = document.querySelector('.increase');
const reset = document.querySelector('.reset');

let counter = 0;

decrease.addEventListener('click', function(){
    counter--;
    count.textContent = counter;
    checkValue();
});

increase.addEventListener('click', function(){
    counter++;
    count.textContent = counter;
    checkValue();
});

reset.addEventListener('click', function(){
    counter = 0;
    count.textContent = counter;
    checkValue();
});

function checkValue(){
    if(counter<0){
        count.style.color = 'red';
    }
    else if(counter>0){
        count.style.color = 'green';
    }
    else {
        count.style.color = 'blue';
    }

}