//Traverse DOM

// const btns =  document.querySelectorAll('.btn');

// btns.forEach(function(btn){
    
// btn.addEventListener('click', function(e){
// const clickedBtn = e.currentTarget.parentElement.parentElement;
// //set flag to check whether target is already open
// let classFlag = false;
// console.log(clickedBtn);
// if(clickedBtn.classList.contains('show-answer')){
//     classFlag = true;
// }
// console.log(classFlag);
    
// btns.forEach(function(btn){
// btn.parentElement.parentElement.classList.remove('show-answer')
// });
// if(classFlag === false){
// clickedBtn.classList.add('show-answer');
// }
// });
// });

//

//Using Selectors
const articles = document.querySelectorAll('.question');

articles.forEach(function(article){

    const btn = article.querySelector('.btn');
    
    btn.addEventListener('click', function(e){
    let classFlag = false;
    clickedBtn= e.currentTarget.parentElement.parentElement;
    console.log(clickedBtn);
    if(clickedBtn.classList.contains('show-answer')){
        classFlag = true;
        console.log(classFlag);
    }
    articles.forEach(function(article){
    article.classList.remove('show-answer');
    });    
    if(classFlag == false){
        clickedBtn.classList.add('show-answer');
    }
    
    })
    

})

